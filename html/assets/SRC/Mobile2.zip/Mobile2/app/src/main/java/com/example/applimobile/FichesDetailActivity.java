package com.example.applimobile;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class FichesDetailActivity extends AppCompatActivity {

    TableLayout tableFraisForfait, tableFraisHorsForfait;
    TextView ficheTitre;
    int ficheId;
    String baseUrl = "http://10.0.2.2/gsb_api/get_by_id";

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultation_fiches); // nom de ton XML

        ficheId = getIntent().getIntExtra("ficheId", -1);

        tableFraisForfait = findViewById(R.id.tableLayoutFraisForfait);
        tableFraisHorsForfait = findViewById(R.id.tablelayoutfraishorsforfait);
        ficheTitre = findViewById(R.id.ficheTitre); // tu peux ajouter un TextView avec cet ID

        if (ficheId != -1) {
            chargerFicheInfo();
            chargerFraisForfaitises();
            chargerFraisHorsForfait();
        } else {
            Toast.makeText(this, "Fiche introuvable", Toast.LENGTH_SHORT).show();
        }
    }

    private void chargerFicheInfo() {
        String url = baseUrl + "fiches/get.php?id=" + ficheId;
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.GET, url, null,
                response -> {
                    try {
                        String mois = response.getString("mois");
                        ficheTitre.setText("Fiche de Frais du " + mois);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                },
                error -> Toast.makeText(this, "Erreur chargement fiche", Toast.LENGTH_SHORT).show()
        );
        Volley.newRequestQueue(this).add(request);
    }

    private void chargerFraisForfaitises() {
        String url = baseUrl + "elementsforfaitises.php?fichefraisId=" + ficheId;
        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET, url, null,
                response -> {
                    for (int i = 0; i < response.length(); i++) {
                        try {
                            JSONObject obj = response.getJSONObject(i);
                            String type = obj.getString("typeforfait");
                            int quantite = obj.getInt("quantite");
                            double montant = obj.getDouble("montant");
                            double total = quantite * montant;

                            TableRow row = new TableRow(this);
                            row.addView(createTextView(type));
                            row.addView(createTextView(String.valueOf(quantite)));
                            row.addView(createTextView(montant + " €"));
                            row.addView(createTextView(String.format("%.2f €", total)));

                            tableFraisForfait.addView(row);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                error -> Toast.makeText(this, "Erreur forfaitisés", Toast.LENGTH_SHORT).show()
        );
        Volley.newRequestQueue(this).add(request);
    }

    private void chargerFraisHorsForfait() {
        String url = baseUrl + "elementshorsforfait.php?fichefraisId=" + ficheId;
        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET, url, null,
                response -> {
                    for (int i = 0; i < response.length(); i++) {
                        try {
                            JSONObject obj = response.getJSONObject(i);
                            String date = obj.getString("date");
                            String libelle = obj.getString("libelle");
                            String montant = obj.getString("montant") + " €";

                            TableRow row = new TableRow(this);
                            row.addView(createTextView(date));
                            row.addView(createTextView(libelle));
                            row.addView(createTextView(montant));

                            tableFraisHorsForfait.addView(row);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                error -> Toast.makeText(this, "Erreur hors forfait", Toast.LENGTH_SHORT).show()
        );
        Volley.newRequestQueue(this).add(request);
    }

    private TextView createTextView(String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setPadding(8, 8, 8, 8);
        return tv;
    }
}
