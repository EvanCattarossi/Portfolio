package com.example.applimobile;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class AfficherFichesActivity extends AppCompatActivity {

    TableLayout tableLayoutFiches;
    int utilisateurId;
    String urlBase = "http://10.0.2.2/gsb_api/fiches/get_all.php?utilisateurId=";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_afficher_fiches); // adapte le nom à ton fichier XML

        tableLayoutFiches = findViewById(R.id.tableLayoutFiches);
        utilisateurId = getIntent().getIntExtra("utilisateurId", -1);

        if (utilisateurId != -1) {
            chargerFiches(utilisateurId);
        } else {
            Toast.makeText(this, "Utilisateur inconnu", Toast.LENGTH_SHORT).show();
        }
    }

    private void chargerFiches(int id) {
        String url = urlBase + id;

        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                url,
                null,
                response -> afficherFiches(response),
                error -> Toast.makeText(this, "Erreur de chargement", Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(this).add(request);
    }

    private void afficherFiches(JSONArray fiches) {
        try {
            for (int i = 0; i < fiches.length(); i++) {
                JSONObject fiche = fiches.getJSONObject(i);
                String mois = fiche.getString("mois");
                String montant = fiche.getString("montantValide") + " €";
                String etat = fiche.getString("etat");
                int ficheId = fiche.getInt("id");

                TableRow row = new TableRow(this);
                row.setLayoutParams(new TableRow.LayoutParams(
                        TableRow.LayoutParams.MATCH_PARENT,
                        TableRow.LayoutParams.WRAP_CONTENT));

                TextView colMois = new TextView(this);
                colMois.setText(mois);
                colMois.setPadding(8, 8, 8, 8);

                TextView colMontant = new TextView(this);
                colMontant.setText(montant);
                colMontant.setPadding(8, 8, 8, 8);

                TextView colEtat = new TextView(this);
                colEtat.setText(etat);
                colEtat.setPadding(8, 8, 8, 8);

                Button btnConsulter = new Button(this);
                btnConsulter.setText("Consulter");
                btnConsulter.setOnClickListener(v -> {
                    Intent intent = new Intent(this, FichesDetailActivity.class);
                    intent.putExtra("ficheId", ficheId);
                    startActivity(intent);
                });

                row.addView(colMois);
                row.addView(colMontant);
                row.addView(colEtat);
                row.addView(btnConsulter);

                tableLayoutFiches.addView(row);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Erreur JSON", Toast.LENGTH_SHORT).show();
        }
    }
}
