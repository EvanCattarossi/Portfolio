package com.example.applimobile;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class RefusFichesActivity extends AppCompatActivity {

    private EditText inputCommentaireRefus;
    private Button btnValiderRefus;

    private int ficheId;
    private static final String URL_REFUSER = "http://10.0.2.2/gsb_api/fiches/refus.php"; // Modifie l’URL si nécessaire

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_refus_commentaire); // nom de ton fichier XML

        inputCommentaireRefus = findViewById(R.id.inputCommentaireRefus);
        btnValiderRefus = findViewById(R.id.btnValiderRefus);

        // Récupération de l'ID de la fiche depuis l'Intent
        ficheId = getIntent().getIntExtra("ficheId", -1);
        if (ficheId == -1) {
            Toast.makeText(this, "Fiche non valide", Toast.LENGTH_SHORT).show();
            finish();
        }

        btnValiderRefus.setOnClickListener(v -> envoyerRefus());
    }

    private void envoyerRefus() {
        String commentaire = inputCommentaireRefus.getText().toString().trim();
        if (commentaire.isEmpty()) {
            Toast.makeText(this, "Merci de saisir un commentaire", Toast.LENGTH_SHORT).show();
            return;
        }

        JSONObject data = new JSONObject();
        try {
            data.put("ficheId", ficheId);
            data.put("commentaire", commentaire);
        } catch (JSONException e) {
            e.printStackTrace();
            return;
        }

        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST,
                URL_REFUSER,
                data,
                response -> Toast.makeText(this, "Fiche refusée", Toast.LENGTH_SHORT).show(),
                error -> Toast.makeText(this, "Erreur de refus", Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(this).add(request);
    }
}
