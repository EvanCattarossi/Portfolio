package com.example.applimobile;

import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class FicheRecyclerAdapter extends RecyclerView.Adapter {
    public FicheRecyclerAdapter(List<RenseignerFicheActivity> ficheList, ListeFichesActivity listeFichesActivity) {
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return null;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {

    }

    @Override
    public int getItemCount() {
        return 0;
    }

    // Fiche.java (Modèle de donnée)
    public class Fiche {
        private int id;
        private String mois;
        private double montantValide;
        private String etat;

        public Fiche(int id, String mois, double montantValide, String etat) {
            this.id = id;
            this.mois = mois;
            this.montantValide = montantValide;
            this.etat = etat;
        }

        public int getId() { return id; }
        public String getMois() { return mois; }
        public double getMontantValide() { return montantValide; }
        public String getEtat() { return etat; }
    }

}
