package com.example.applimobile;

import android.os.Bundle;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class RemboursementActivity extends AppCompatActivity {

    LinearLayout linearLayoutTable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Ton layout XML avec HorizontalScrollView

        linearLayoutTable = findViewById(R.id.table_container); // Ajoute un id dans le XML au LinearLayout parent

        fetchFichesDeFrais();
    }

    private void fetchFichesDeFrais() {
        String url = "http://10.0.2.2/gsb_api/fiches/get_all.php"; // remplace par l'URL réelle

        RequestQueue queue = Volley.newRequestQueue(this);

        JsonArrayRequest request = new JsonArrayRequest(Request.Method.GET, url, null,
                response -> {
                    try {
                        for (int i = 0; i < response.length(); i++) {
                            JSONObject fiche = response.getJSONObject(i);
                            addRow(
                                    fiche.getString("nom"),
                                    fiche.getString("mois"),
                                    fiche.getDouble("montant")
                            );
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Erreur parsing JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Erreur réseau : " + error.getMessage(), Toast.LENGTH_SHORT).show()
        );

        queue.add(request);
    }

    private void addRow(String nom, String mois, double montant) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(8, 8, 8, 8);
        row.setLayoutParams(new ScrollView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView nomView = new TextView(this);
        nomView.setText(nom);
        nomView.setWidth(120);

        TextView moisView = new TextView(this);
        moisView.setText(mois);
        moisView.setWidth(100);

        TextView montantView = new TextView(this);
        montantView.setText(String.format("%.2f €", montant));
        montantView.setWidth(100);

        LinearLayout actionsLayout = new LinearLayout(this);
        actionsLayout.setOrientation(LinearLayout.HORIZONTAL);
        actionsLayout.setLayoutParams(new LinearLayout.LayoutParams(200, ViewGroup.LayoutParams.WRAP_CONTENT));

        Button btnRembourser = new Button(this);
        btnRembourser.setText("Rembourser");
        btnRembourser.setTextSize(12);
        btnRembourser.setWidth(90);
        btnRembourser.setTextColor(getResources().getColor(android.R.color.white));
        btnRembourser.setBackgroundResource(R.drawable.rounded_green_button);

        Button btnRefuser = new Button(this);
        btnRefuser.setText("Refuser");
        btnRefuser.setTextSize(12);
        btnRefuser.setWidth(90);
        btnRefuser.setTextColor(getResources().getColor(android.R.color.white));
        btnRefuser.setBackgroundResource(R.drawable.rounded_red_button);

        actionsLayout.addView(btnRembourser);
        actionsLayout.addView(btnRefuser);

        row.addView(nomView);
        row.addView(moisView);
        row.addView(montantView);
        row.addView(actionsLayout);

        linearLayoutTable.addView(row);
    }
}
