package com.example.applimobile;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ModifierFichesActivity extends AppCompatActivity {

    EditText editKM, editNL, editREP;
    EditText editDate1, editLibelle1, editMontant1;
    EditText editDate2, editLibelle2, editMontant2;
    Button btnEnregistrer;
    int ficheId;

    String baseUrl = "http://10.0.2.2/gsb_api/fiches/update.php";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_modifier_fiches);

        ficheId = getIntent().getIntExtra("ficheId", -1);

        editKM = findViewById(R.id.editKM);
        editNL = findViewById(R.id.editNL);
        editREP = findViewById(R.id.editREP);

        editDate1 = findViewById(R.id.editDate1);
        editLibelle1 = findViewById(R.id.editLibelle1);
        editMontant1 = findViewById(R.id.editMontant1);

        editDate2 = findViewById(R.id.editDate2);
        editLibelle2 = findViewById(R.id.editLibelle2);
        editMontant2 = findViewById(R.id.editMontant2);

        btnEnregistrer = findViewById(R.id.btnEnregistrer);

        btnEnregistrer.setOnClickListener(v -> enregistrerModifications());
    }

    private void enregistrerModifications() {
        JSONObject data = new JSONObject();
        JSONArray forfaitises = new JSONArray();
        JSONArray horsForfait = new JSONArray();

        try {
            data.put("fichefraisId", ficheId);

            forfaitises.put(new JSONObject().put("typeforfait", "KM").put("quantite", editKM.getText().toString()));
            forfaitises.put(new JSONObject().put("typeforfait", "NUI").put("quantite", editNL.getText().toString()));
            forfaitises.put(new JSONObject().put("typeforfait", "REP").put("quantite", editREP.getText().toString()));
            data.put("forfaitises", forfaitises);

            horsForfait.put(new JSONObject()
                    .put("date", editDate1.getText().toString())
                    .put("libelle", editLibelle1.getText().toString())
                    .put("montant", editMontant1.getText().toString()));
            horsForfait.put(new JSONObject()
                    .put("date", editDate2.getText().toString())
                    .put("libelle", editLibelle2.getText().toString())
                    .put("montant", editMontant2.getText().toString()));
            data.put("horsforfait", horsForfait);

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Erreur JSON", Toast.LENGTH_SHORT).show();
            return;
        }

        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST,
                baseUrl + "fiches/update.php", // À créer côté PHP
                data,
                response -> Toast.makeText(this, "Modifications enregistrées", Toast.LENGTH_SHORT).show(),
                error -> Toast.makeText(this, "Erreur d'enregistrement", Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(this).add(request);
    }
}
