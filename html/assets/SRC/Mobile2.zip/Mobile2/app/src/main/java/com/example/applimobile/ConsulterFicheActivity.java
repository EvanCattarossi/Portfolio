package com.example.applimobile;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ConsulterFicheActivity extends AppCompatActivity {

    private TableLayout fraisForfaitTable;
    private TableLayout horsForfaitTable;
    private int ficheId;
    private final String apiUrl = "http://10.0.2.2/gsb_api/fiches/get_by_id.php"; // à adapter si besoin

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultation_fiches);

        fraisForfaitTable = findViewById(R.id.fraisForfaitTable);
        horsForfaitTable = findViewById(R.id.horsForfaitTable);

        ficheId = getIntent().getIntExtra("ficheId", -1);
        if (ficheId == -1) {
            Toast.makeText(this, "Fiche introuvable", Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        chargerDetailsFiche();
    }

    private void chargerDetailsFiche() {
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.GET,
                apiUrl + ficheId,
                null,
                response -> {
                    try {
                        JSONArray forfait = response.getJSONArray("fraisForfaitises");
                        JSONArray horsForfait = response.getJSONArray("fraisHorsForfait");

                        for (int i = 0; i < forfait.length(); i++) {
                            JSONObject item = forfait.getJSONObject(i);
                            ajouterLigneFraisForfait(item);
                        }

                        for (int i = 0; i < horsForfait.length(); i++) {
                            JSONObject item = horsForfait.getJSONObject(i);
                            ajouterLigneHorsForfait(item);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Erreur JSON", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Erreur réseau", Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(this).add(request);
    }

    private void ajouterLigneFraisForfait(JSONObject item) throws JSONException {
        TableRow row = new TableRow(this);

        TextView type = creerCellule(item.getString("type"));
        TextView quantite = creerCellule(item.getString("quantite"));
        TextView montantUnitaire = creerCellule(item.getString("montantUnitaire") + " €");
        TextView total = creerCellule(item.getString("total") + " €");

        row.addView(type);
        row.addView(quantite);
        row.addView(montantUnitaire);
        row.addView(total);

        fraisForfaitTable.addView(row);
    }

    private void ajouterLigneHorsForfait(JSONObject item) throws JSONException {
        TableRow row = new TableRow(this);

        TextView date = creerCellule(item.getString("date"));
        TextView libelle = creerCellule(item.getString("libelle"));
        TextView montant = creerCellule(item.getString("montant") + " €");

        row.addView(date);
        row.addView(libelle);
        row.addView(montant);

        horsForfaitTable.addView(row);
    }

    private TextView creerCellule(String texte) {
        TextView tv = new TextView(this);
        tv.setText(texte);
        tv.setPadding(8, 8, 8, 8);
        return tv;
    }
}
