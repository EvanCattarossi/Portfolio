package com.example.applimobile;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class AdminDashboardActivity extends AppCompatActivity {

    Button btnAjoutUtilisateurs, btnFichesTousRoles, btnDeconnexionAdmin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_admin); // nom de ton layout XML

        btnAjoutUtilisateurs = findViewById(R.id.btnAjoutUtilisateurs);
        btnFichesTousRoles = findViewById(R.id.btnFichesTousRoles);
        btnDeconnexionAdmin = findViewById(R.id.btnDeconnexionAdmin);

        btnAjoutUtilisateurs.setOnClickListener(v -> {
            Intent intent = new Intent(this, AjoutUtilisateurActivity.class);
            startActivity(intent);
        });

        btnFichesTousRoles.setOnClickListener(v -> {
            Intent intent = new Intent(this, ListeTableauUtilisateursActivity.class);
            startActivity(intent);
        });

        btnDeconnexionAdmin.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }
}
