package com.example.applimobile;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

// ... package et imports inchangés

public class MainActivity extends AppCompatActivity {

    EditText email, password;
    Button login;
    ProgressDialog progressDialog;
    RequestQueue requestQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        email = findViewById(R.id.inputEmail);
        password = findViewById(R.id.inputPassword);
        login = findViewById(R.id.btnLogin);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Connexion...");
        progressDialog.setCancelable(false);

        requestQueue = Volley.newRequestQueue(this);

        login.setOnClickListener(v -> {
            String userEmail = email.getText().toString().trim().toLowerCase();
            String userPass = password.getText().toString().trim();

            if (userEmail.isEmpty()) {
                Toast.makeText(this, "Veuillez saisir votre e-mail", Toast.LENGTH_SHORT).show();
            } else if (userPass.isEmpty()) {
                Toast.makeText(this, "Veuillez saisir votre mot de passe", Toast.LENGTH_SHORT).show();
            } else {
                loginRequest(userEmail, userPass);
            }
        });
    }

    private void loginRequest(String userEmail, String userPass) {
        String loginUrl = "http://10.0.2.2/gsb-api/login.php";

        progressDialog.show();

        StringRequest stringRequest = new StringRequest(Request.Method.POST, loginUrl,
                response -> {
                    progressDialog.dismiss();
                    Log.d("REPONSE_API", response);

                    try {
                        JSONObject json = new JSONObject(response);

                        if (json.optBoolean("success")) {
                            Toast.makeText(this, "Connexion réussie !", Toast.LENGTH_SHORT).show();

                            JSONObject user = json.getJSONObject("utilisateur");

                            SharedPreferences prefs = getSharedPreferences("session", Context.MODE_PRIVATE);
                            SharedPreferences.Editor editor = prefs.edit();
                            editor.putString("id", user.optString("id", ""));
                            editor.putString("role", user.optString("role", ""));
                            editor.putString("email", user.optString("email", ""));
                            editor.apply();

                            String role = user.optString("role", "").toLowerCase();
                            Log.d("ROLE_DEBUG", "Rôle reçu : " + role);

                            Intent intent = null;

                            switch (role) {
                                case "visiteur":
                                    intent = new Intent(this, VisiteurDashboardActivity.class);
                                    break;
                                case "comptable":
                                    intent = new Intent(this, ComptableDashboardActivity.class);
                                    break;
                                case "administrateur":
                                    intent = new Intent(this, AdminDashboardActivity.class);
                                    break;
                                default:
                                    Toast.makeText(this, "Rôle inconnu : " + role, Toast.LENGTH_LONG).show();
                                    return;
                            }

                            // ✅ Passer l'ID utilisateur dans l'Intent
                            int userId = user.optInt("id", -1);
                            intent.putExtra("utilisateurId", userId);

                            if (intent != null) {
                                Log.d("DEBUG_REDIRECT", "Redirection vers : " + intent.getComponent().getClassName());
                                startActivity(intent);
                                finish();
                            }

                        } else {
                            String errMsg = json.optString("error", "Identifiants incorrects");
                            Toast.makeText(this, errMsg, Toast.LENGTH_LONG).show();
                        }
                    } catch (JSONException e) {
                        Toast.makeText(this, "Erreur JSON", Toast.LENGTH_LONG).show();
                        Log.e("REPONSE_API", "JSONException : " + e.getMessage());
                    }
                },
                error -> {
                    progressDialog.dismiss();

                    if (error.networkResponse != null) {
                        int statusCode = error.networkResponse.statusCode;
                        String responseBody = new String(error.networkResponse.data);
                        Log.e("REPONSE_API", "Erreur HTTP : " + statusCode);
                        Log.e("REPONSE_API", "Contenu réponse : " + responseBody);
                        Toast.makeText(this, "Erreur réseau (" + statusCode + ")", Toast.LENGTH_LONG).show();
                    } else {
                        Log.e("REPONSE_API", "Erreur sans réponse réseau : " + error.toString());
                        Toast.makeText(this, "Erreur réseau inconnue", Toast.LENGTH_LONG).show();
                    }
                }
        ) {
            @Override
            protected Map<String, String> getParams() {
                Log.d("DEBUG_FORM", "email=" + userEmail + " | password=" + userPass);
                Map<String, String> params = new HashMap<>();
                params.put("email", userEmail);
                params.put("password", userPass);
                return params;
            }
        };

        stringRequest.setRetryPolicy(new DefaultRetryPolicy(
                10000, DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT));

        requestQueue.add(stringRequest);
    }
}
