package com.example.applimobile;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class RenseignerFicheActivity extends AppCompatActivity {

    private EditText editDate, editKm, editHotel, editRepas;
    private EditText editHfDate, editHfLibelle, editHfMontant;
    private Button btnAjouterHf;

    private int utilisateurId;
    private static final String URL_CREATE = "http://10.0.2.2/gsb-api/fiches/create.php";

    public RenseignerFicheActivity(int id, String mois, double montantValide, String etat) {
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_renseigner_fiche);

        utilisateurId = getIntent().getIntExtra("utilisateurId", -1);

        editDate = findViewById(R.id.editTextDate);
        editKm = findViewById(R.id.editKm);
        editHotel = findViewById(R.id.editHotel);
        editRepas = findViewById(R.id.editRepas);

        editHfDate = findViewById(R.id.editHorsForfaitDate);
        editHfLibelle = findViewById(R.id.editHorsForfaitLibelle);
        editHfMontant = findViewById(R.id.editHorsForfaitMontant);

        btnAjouterHf = findViewById(R.id.btnAjouterHorsForfait);

        btnAjouterHf.setOnClickListener(v -> ajouterFicheFrais());
    }

    private void ajouterFicheFrais() {
        String date = editDate.getText().toString().trim();
        if (date.isEmpty()) {
            Toast.makeText(this, "Veuillez renseigner la date", Toast.LENGTH_SHORT).show();
            return;
        }

        int km = getIntFromField(editKm);
        int hotel = getIntFromField(editHotel);
        int repas = getIntFromField(editRepas);

        String hfDate = editHfDate.getText().toString().trim();
        String hfLibelle = editHfLibelle.getText().toString().trim();
        String hfMontantStr = editHfMontant.getText().toString().trim();
        double hfMontant = hfMontantStr.isEmpty() ? 0 : Double.parseDouble(hfMontantStr);

        try {
            JSONObject fiche = new JSONObject();
            fiche.put("utilisateurId", utilisateurId);
            fiche.put("date", date);

            JSONArray forfait = new JSONArray();
            forfait.put(new JSONObject().put("type", "km").put("quantite", km));
            forfait.put(new JSONObject().put("type", "nui").put("quantite", hotel));
            forfait.put(new JSONObject().put("type", "rep").put("quantite", repas));

            JSONArray horsForfait = new JSONArray();
            if (!hfDate.isEmpty() && !hfLibelle.isEmpty() && hfMontant > 0) {
                JSONObject hf = new JSONObject();
                hf.put("date", hfDate);
                hf.put("libelle", hfLibelle);
                hf.put("montant", hfMontant);
                horsForfait.put(hf);
            }

            fiche.put("forfait", forfait);
            fiche.put("horsForfait", horsForfait);

            JsonObjectRequest request = new JsonObjectRequest(
                    Request.Method.POST,
                    URL_CREATE,
                    fiche,
                    response -> Toast.makeText(this, "Fiche enregistrée", Toast.LENGTH_SHORT).show(),
                    error -> Toast.makeText(this, "Erreur d’enregistrement", Toast.LENGTH_SHORT).show()
            );

            Volley.newRequestQueue(this).add(request);

        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Erreur JSON", Toast.LENGTH_SHORT).show();
        }
    }

    private int getIntFromField(EditText field) {
        String text = field.getText().toString().trim();
        return text.isEmpty() ? 0 : Integer.parseInt(text);
    }
}
