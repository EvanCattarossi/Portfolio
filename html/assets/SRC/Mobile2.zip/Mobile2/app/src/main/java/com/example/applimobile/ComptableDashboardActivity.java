package com.example.applimobile;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class ComptableDashboardActivity extends AppCompatActivity {

    Button btnConsulterFiches, btnRemboursement, btnDeconnexion;
    int utilisateurId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_comptable); // Assure-toi que ce layout existe

        // Liaison aux boutons
        btnConsulterFiches = findViewById(R.id.btnConsulterFiches);
        btnRemboursement = findViewById(R.id.btnRemboursement);
        btnDeconnexion = findViewById(R.id.btnDeconnexion);

        // Récupération de l'ID utilisateur depuis la session ou Intent
        utilisateurId = getIntent().getIntExtra("utilisateurId", -1);

        // Redirection vers la liste des fiches à valider/rembourser
        btnConsulterFiches.setOnClickListener(v -> {
            Intent i = new Intent(this, ListeFichesComptableActivity.class);
            i.putExtra("utilisateurId", utilisateurId); // utile si besoin dans l'activité suivante
            startActivity(i);
        });

        // Redirection vers la page de remboursement
        btnRemboursement.setOnClickListener(v -> {
            Intent i = new Intent(this, RemboursementActivity.class);
            i.putExtra("utilisateurId", utilisateurId);
            startActivity(i);
        });

        // Déconnexion
        btnDeconnexion.setOnClickListener(v -> {
            Intent i = new Intent(this, MainActivity.class);
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK); // Efface la pile
            startActivity(i);
            finish();
        });
    }
}
