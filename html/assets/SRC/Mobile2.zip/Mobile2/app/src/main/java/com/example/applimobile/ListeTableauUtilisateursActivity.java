package com.example.applimobile;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ListeTableauUtilisateursActivity extends AppCompatActivity {

    private LinearLayout tableauContainer;
    private static final String URL_UTILISATEURS = "http://10.0.2.2/gsb_api/utilisateurs/get_all.php"; // modifie l'URL si besoin

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_utilisateurs_tableau); // ton fichier XML

        tableauContainer = findViewById(R.id.tableauContainer);

        chargerUtilisateurs();
    }

    private void chargerUtilisateurs() {
        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                URL_UTILISATEURS,
                null,
                response -> afficherUtilisateurs(response),
                error -> Toast.makeText(this, "Erreur lors du chargement", Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(this).add(request);
    }

    private void afficherUtilisateurs(JSONArray utilisateurs) {
        try {
            for (int i = 0; i < utilisateurs.length(); i++) {
                JSONObject utilisateur = utilisateurs.getJSONObject(i);

                String nom = utilisateur.getString("nom");
                String prenom = utilisateur.getString("prenom");
                String email = utilisateur.getString("email");
                String role = utilisateur.getString("role");

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(8, 8, 8, 8);

                TextView tvNom = new TextView(this);
                tvNom.setText(nom);
                tvNom.setLayoutParams(new LinearLayout.LayoutParams(100, LinearLayout.LayoutParams.WRAP_CONTENT));
                tvNom.setPadding(4, 4, 4, 4);

                TextView tvPrenom = new TextView(this);
                tvPrenom.setText(prenom);
                tvPrenom.setLayoutParams(new LinearLayout.LayoutParams(100, LinearLayout.LayoutParams.WRAP_CONTENT));
                tvPrenom.setPadding(4, 4, 4, 4);

                TextView tvEmail = new TextView(this);
                tvEmail.setText(email);
                tvEmail.setLayoutParams(new LinearLayout.LayoutParams(180, LinearLayout.LayoutParams.WRAP_CONTENT));
                tvEmail.setPadding(4, 4, 4, 4);

                TextView tvRole = new TextView(this);
                tvRole.setText(role);
                tvRole.setLayoutParams(new LinearLayout.LayoutParams(120, LinearLayout.LayoutParams.WRAP_CONTENT));
                tvRole.setPadding(4, 4, 4, 4);

                row.addView(tvNom);
                row.addView(tvPrenom);
                row.addView(tvEmail);
                row.addView(tvRole);

                tableauContainer.addView(row);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Erreur JSON", Toast.LENGTH_SHORT).show();
        }
    }
}
