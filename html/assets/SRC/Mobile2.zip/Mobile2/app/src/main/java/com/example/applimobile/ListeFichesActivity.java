// ListeFichesActivity.java
package com.example.applimobile;

import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class ListeFichesActivity extends AppCompatActivity {

    RecyclerView recyclerFiches;
    ArrayList<RenseignerFicheActivity> ficheList = new ArrayList<>();
    FicheRecyclerAdapter adapter;
    int utilisateurId;
    String url = "http://10.0.2.2/gsb_api/fiches/get_by_id";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_fiches);

        recyclerFiches = findViewById(R.id.recyclerFiches);
        recyclerFiches.setLayoutManager(new LinearLayoutManager(this));

        utilisateurId = getIntent().getIntExtra("utilisateurId", -1);

        if (utilisateurId == -1) {
            Toast.makeText(this, "Utilisateur invalide", Toast.LENGTH_SHORT).show();
            finish();
        }

        fetchFiches();
    }

    private void fetchFiches() {
        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                url + utilisateurId,
                null,
                response -> {
                    ficheList.clear();
                    for (int i = 0; i < response.length(); i++) {
                        try {
                            JSONObject obj = response.getJSONObject(i);
                            ficheList.add(new RenseignerFicheActivity(
                                    obj.getInt("id"),
                                    obj.getString("mois"),
                                    obj.getDouble("montantValide"),
                                    obj.getString("etat")
                            ));
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                    adapter = new FicheRecyclerAdapter(ficheList, ListeFichesActivity.this);
                    recyclerFiches.setAdapter(adapter);
                },
                error -> Toast.makeText(this, "Erreur chargement fiches", Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(this).add(request);
    }
}
