package com.example.applimobile;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class ListeFichesComptableActivity extends AppCompatActivity {

    LinearLayout containerFiches;
    String apiUrl = "http://10.0.2.2/gsb_api/fiches/get_all.php"; // adapte l’URL si besoin

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_fiches_comptable);

        containerFiches = findViewById(R.id.containerFiches);

        chargerFiches();
    }

    private void chargerFiches() {
        JsonArrayRequest request = new JsonArrayRequest(
                Request.Method.GET,
                apiUrl,
                null,
                response -> {
                    for (int i = 0; i < response.length(); i++) {
                        try {
                            JSONObject fiche = response.getJSONObject(i);
                            ajouterLigneFiche(fiche);
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                },
                error -> Toast.makeText(this, "Erreur lors du chargement", Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(this).add(request);
    }

    private void ajouterLigneFiche(JSONObject fiche) throws JSONException {
        LinearLayout ligne = new LinearLayout(this);
        ligne.setOrientation(LinearLayout.HORIZONTAL);
        ligne.setPadding(8, 8, 8, 8);

        String nom = fiche.getString("nom") + " " + fiche.getString("prenom");
        String mois = fiche.getString("mois");
        String montant = fiche.getString("montantValide") + " €";
        String etat = fiche.getString("etat");

        TextView tvNom = creerCellule(nom);
        TextView tvMois = creerCellule(mois);
        TextView tvMontant = creerCellule(montant);
        TextView tvEtat = creerCellule(etat);

        Button btnConsulter = new Button(this);
        btnConsulter.setText("Consulter");
        btnConsulter.setTextSize(12);
        btnConsulter.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));

        int ficheId = fiche.getInt("id");

        btnConsulter.setOnClickListener(v -> {
            Intent intent = new Intent(this, ConsulterFicheActivity.class);
            intent.putExtra("ficheId", ficheId);
            startActivity(intent);
        });

        ligne.addView(tvNom);
        ligne.addView(tvMois);
        ligne.addView(tvMontant);
        ligne.addView(tvEtat);
        ligne.addView(btnConsulter);

        containerFiches.addView(ligne);
    }

    private TextView creerCellule(String texte) {
        TextView tv = new TextView(this);
        tv.setText(texte);
        tv.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
        tv.setPadding(8, 8, 8, 8);
        return tv;
    }
}
