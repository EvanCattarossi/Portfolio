package com.example.applimobile;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class VisiteurDashboardActivity extends AppCompatActivity {

    Button btnNewFiche, btnViewFiches, btnLogout;
    int utilisateurId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard_visiteur);

        // Initialisation
        btnNewFiche = findViewById(R.id.btnNewFiche);
        btnViewFiches = findViewById(R.id.btnViewFiches);
        btnLogout = findViewById(R.id.btnLogout);

        // Récupération de l'utilisateur connecté
        utilisateurId = getIntent().getIntExtra("utilisateurId", -1);
        if (utilisateurId == -1) {
            Toast.makeText(this, "Erreur utilisateur", Toast.LENGTH_SHORT).show();
            finish();
        }

        // Redirection vers activité de saisie
        btnNewFiche.setOnClickListener(v -> {
            Intent intent = new Intent(this, RenseignerFicheActivity.class);
            intent.putExtra("utilisateurId", utilisateurId);
            startActivity(intent);
        });

        // Redirection vers la liste des fiches
        btnViewFiches.setOnClickListener(v -> {
            Intent intent = new Intent(this, AfficherFichesActivity.class);
            intent.putExtra("utilisateurId", utilisateurId);
            startActivity(intent);
        });

        // Déconnexion
        btnLogout.setOnClickListener(v -> {
            Intent intent = new Intent(this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            Toast.makeText(this, "Déconnecté", Toast.LENGTH_SHORT).show();
        });
    }
}
