package com.example.applimobile;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class AjoutUtilisateurActivity extends AppCompatActivity {

    EditText inputNom, inputPrenom, inputEmail, inputPassword;
    Spinner spinnerRole;
    Button btnCreerUtilisateur;

    String url = "http://10.0.2.2/gsb_api/utilisateurs/create.php"; // modifie si nécessaire

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajout_utilisateur); // adapte à ton nom de layout

        // Liaison avec les vues
        inputNom = findViewById(R.id.inputNom);
        inputPrenom = findViewById(R.id.inputPrenom);
        inputEmail = findViewById(R.id.inputEmail);
        inputPassword = findViewById(R.id.inputPassword);
        spinnerRole = findViewById(R.id.spinnerRole);
        btnCreerUtilisateur = findViewById(R.id.btnCreerUtilisateur);

        // Remplir le Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"visiteur", "comptable", "administrateur"});
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerRole.setAdapter(adapter);

        // Click bouton
        btnCreerUtilisateur.setOnClickListener(v -> creerUtilisateur());
    }

    private void creerUtilisateur() {
        String nom = inputNom.getText().toString().trim();
        String prenom = inputPrenom.getText().toString().trim();
        String email = inputEmail.getText().toString().trim();
        String password = inputPassword.getText().toString().trim();
        String role = spinnerRole.getSelectedItem().toString();

        if (nom.isEmpty() || prenom.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Veuillez remplir tous les champs", Toast.LENGTH_SHORT).show();
            return;
        }

        // Création du JSON
        JSONObject userData = new JSONObject();
        try {
            userData.put("nom", nom);
            userData.put("prenom", prenom);
            userData.put("email", email);
            userData.put("password", password);
            userData.put("role", role);
        } catch (JSONException e) {
            e.printStackTrace();
            Toast.makeText(this, "Erreur JSON", Toast.LENGTH_SHORT).show();
            return;
        }

        // Envoi avec Volley
        JsonObjectRequest request = new JsonObjectRequest(
                Request.Method.POST,
                url,
                userData,
                response -> Toast.makeText(this, "Utilisateur ajouté avec succès", Toast.LENGTH_SHORT).show(),
                error -> Toast.makeText(this, "Erreur lors de l'ajout", Toast.LENGTH_SHORT).show()
        );

        Volley.newRequestQueue(this).add(request);
    }
}
